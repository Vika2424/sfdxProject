/**
 * Created by vpelykh on 19.01.2022.
 */

import {LightningElement} from 'lwc';

export default class Test extends LightningElement {

}